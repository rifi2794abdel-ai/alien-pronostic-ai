
import os
import sqlite3
import joblib
import pandas as pd
from flask import Flask, request, jsonify
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

app = Flask(__name__)

DATA_FOLDER = "data"
MODEL_PATH = "models/model.pkl"
DB_PATH = "predictions.db"

def load_all_excel_data(folder):
    all_files = []
    for root, _, files in os.walk(folder):
        for file in files:
            if file.endswith(".xlsx"):
                all_files.append(os.path.join(root, file))

    if not all_files:
        raise Exception("No Excel files found in data folder")

    df_list = [pd.read_excel(file) for file in all_files]
    return pd.concat(df_list, ignore_index=True)

def train_and_save_model():
    df = load_all_excel_data(DATA_FOLDER)
    df = df.dropna()

    X = df[["home_avg_goals", "away_avg_goals", "home_xg", "away_xg"]]
    y = df["result"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)

    os.makedirs("models", exist_ok=True)
    joblib.dump(model, MODEL_PATH)

    print("Model accuracy:", acc)
    return acc

def load_model():
    if not os.path.exists(MODEL_PATH):
        train_and_save_model()
    return joblib.load(MODEL_PATH)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "CREATE TABLE IF NOT EXISTS predictions ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "home_avg_goals REAL,"
        "away_avg_goals REAL,"
        "home_xg REAL,"
        "away_xg REAL,"
        "prediction INTEGER)"
    )
    conn.commit()
    conn.close()

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json

    required_fields = ["home_avg_goals", "away_avg_goals", "home_xg", "away_xg"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": "Missing fields"}), 400

    model = load_model()

    input_df = pd.DataFrame([[
        data["home_avg_goals"],
        data["away_avg_goals"],
        data["home_xg"],
        data["away_xg"]
    ]], columns=required_fields)

    prediction = model.predict(input_df)[0]

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "INSERT INTO predictions (home_avg_goals, away_avg_goals, home_xg, away_xg, prediction) "
        "VALUES (?, ?, ?, ?, ?)",
        (
            data["home_avg_goals"],
            data["away_avg_goals"],
            data["home_xg"],
            data["away_xg"],
            int(prediction)
        )
    )
    conn.commit()
    conn.close()

    return jsonify({"prediction": int(prediction)})

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
