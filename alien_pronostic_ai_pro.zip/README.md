# Alien Pronostic AI - Production Version

## Features
- Automatic loading of all Excel (.xlsx) files from /data folder
- Model trained once and saved
- Real train/test accuracy evaluation
- SQLite logging of predictions
- Input validation
- Production ready structure

## Usage
1) Put all your country folders (Belgium, England, etc.) inside /data
2) Install dependencies:
   pip install -r requirements.txt
3) Run:
   python app.py

POST /predict
{
  "home_avg_goals": 1.5,
  "away_avg_goals": 1.2,
  "home_xg": 1.8,
  "away_xg": 1.0
}
